PRATIKSHA GIRLFRIEND DAY WEBSITE

1. Open index.html in a browser to preview.
2. To share as a public link, upload this folder to Netlify Drop or GitHub Pages.
3. The background music is generated in the browser (no copyrighted song). To use your own song later, add an MP3 and replace the music script.

Made for Pratiksha ❤️ from Pushpak.
